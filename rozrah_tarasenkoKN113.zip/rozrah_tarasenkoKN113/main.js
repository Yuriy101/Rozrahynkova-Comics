$('.intro').slick({
  autoplay: true,
  autoplaySpeed: 5000
});
